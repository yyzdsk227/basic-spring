package com.spring.vo;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;


public class SecurityMaker extends SecurityBasic {

	/*private SecurityBasic sesv;
	private MemberVO mvo;
	private RoleVO rvo;
	private BbsVO bvo;
	private boolean identification;
	
	
	public void getCheckData(boolean identifiaction){
		setIdentification(sesv.securityAuthen(mvo).getUsername() == bvo.getWriter() ? false : true);
	}

	public boolean isIdentification() {
		return identification;
	}

	public void setIdentification(boolean identification) {
		this.identification = identification;
	}
*/

		
	
}
