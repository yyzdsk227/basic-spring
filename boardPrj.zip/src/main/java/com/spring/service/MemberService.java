package com.spring.service;



public interface MemberService {
	
	public String secCheck(String writer) throws Exception;
	
}
